// thay doi anh
var h1 = new Image();
var h2 = new Image();
var h3 = new Image();
var h4 = new Image();

function loadAnh() {
    h1.src = "images/anh8.jpg";
    h2.src = "images/anh9.jpg";
    h3.src = "images/anh10.jpg";
    h4.src = "images/anh11.jpg";
}

function anh1() {
    document.img_anh.src = h1.src;
}

function anh2() {
    document.img_anh.src = h2.src;
}

function anh3() {
    document.img_anh.src = h3.src;
}

function anh4() {
    document.img_anh.src = h4.src;
}
// --------------
var n = products.length;

function loadDetail() {
    var id = sessionStorage.getItem('id_Detail');

    for (let i = 0; i < n; i++) {
        let sp = "";
        if (id == products[i].id) {
            sp = `
            <div class="phan1">
                <div class="anhchitiet">
                    <img name="img_anh" src="images/${products[i].image} " class="anhtrai" alt=" ">
                    <div class="row-1">
                        <div class="box-4-1 mg20">
                            <a href="#"><input src="images/${products[i].image}" type="image" alt="Submit" width="70" height="80" onclick="anh1()"></a>
                        </div>
                        <div class="box-4-1 mg20">
                            <a href="#"><input src="images/anh9.jpg" type="image" alt="Submit" width="70" height="80" onclick="anh2()"></a>
                        </div>
                        <div class="box-4-1 mg20">
                            <a href="#"><input src="images/anh10.jpg" type="image" alt="Submit" width="70" height="80" onclick="anh3()"></a>
                        </div>
                        <div class="box-4-1 ">
                            <a href="#"><input src="images/anh11.jpg" type="image" alt="Submit" width="70" height="80" onclick="anh4()"></a>
                        </div>
                    </div>
                </div>
                <div class="noidung">
                    <div class="name1">
                        <a href="#">${products[i].name}</a>
                    </div>
                    <div class="gia1">
                        <a href="#">${products[i].price} VND</a>
                    </div>
                    <div class="chitiet">
                        <ul>
                            <li><strong>Model</strong> : KWH950 </li>
                            <li><strong>Nguồn gốc</strong> : Sản phẩm chính hãng OKIA</li>
                            <li><strong>Điện áp định mức</strong> : 220 -240 V , 50/60 Hz</li>
                            <li><strong>Công suất</strong> : 260 W </li>
                            <li><strong>Thời gian sử dụng định mức</strong> : 20 phút</li>
                            <li><strong>Trọng lượng tịnh</strong> : 152kg </li>
                        </ul>
                    </div>
                    <div class="chitiet">
                        <ul>
                            <li>Ghế massage của thương hiệu OKIA .</li>
                            <li>Thời gian bảo hành của ghế massage: 24 tháng (hàng mới) và 12 tháng (hàng trưng bày) kể từ ngày mua sản phẩm.</li>
                        </ul>
                    </div>
                    <table border="1" class="soluong">
                        <tr>
                            <td class="congtru">-</td>
                            <td class="so">1</td>
                            <td class="congtru">+</td>
                        </tr>
                    </table>
                    <div class="muahang">
                        <a href="#">Mua hàng</a>
                    </div>
                </div>
                <div class="aside">
                    <div class="tuvan">
                        <h4>GỌI NGAY ĐỂ ĐƯỢC TƯ VẤN</h4>
                        <p>Hotline tư vấn</p>
                        <h3>0946.417.284</h3>
                    </div>
                    <div class="vanchuyen">
                        <div class="icons-1">
                            <i class="fa-solid fa-truck-fast"></i>
                        </div>
                        <h3>Miễn phí vận chuyển</h3>
                        <p>khu vực nội thành</p>
                    </div>
                    <div class="vanchuyen">
                        <div class="icons-1">
                            <i class="fa-regular fa-thumbs-up"></i>
                        </div>
                        <h3>Bảo hành 1 năm</h3>
                        <p>chính hãng OEM</p>
                    </div>
                    <div class="vanchuyen">
                        <div class="icons-1">
                            <i class="fa-regular fa-circle-check"></i>
                        </div>
                        <h3>30 ngày hoàn tiền</h3>
                        <p>nếu lỗi do nhà sản xuất</p>
                    </div>
                    <div class="anhaside">
                        <a href="#"><img src="images/anhaside.jpg" alt=""></a>
                    </div>
                </div>
            </div>
            <div class="mota">
                <p>Mô tả</p>
            </div>
            <div class="danhgia">
                <p>Đánh giá (0)</p>
            </div>
            <div class="anhlon">
                <img src="images/anhlon1.jpg" alt="">
            </div>
            <div class="anhlon">
                <img src="images/anhlon2.jpg" alt="">
            </div>
            <div class="noidung-5">
                <h3>1. ĐỐI TƯỢNG ĐƯỢC BẢO HÀNH:</h3>
                <li>Ghế massage của thương hiệu OKIA .</li>
                <h3>2. THỜI HẠN BẢO HÀNH – NÓI CHUNG:</h3>
                <li>Thời gian bảo hành của ghế massage: 24 tháng (hàng mới) và 12 tháng (hàng trưng bày) kể từ ngày mua sản phẩm.</li>
                <h3>3. CÁC TRƯỜNG HỢP SẢN PHẨM KHÔNG ĐƯỢC BẢO HÀNH : </h3>
                <li>Khách hàng không xuất trình được phiếu bảo hành hoặc phiếu bảo hành bị tẩy xóa, sửa chữa nội dung trong phiếu, không có đóng dấu, chữ ký của đại diện bên bán hàng.</li>
                <li>Sản phẩm đã quá thời gian bảo hành.</li>
                <li>Sản phẩm hư hỏng do thiên tai, hỏa hoạn, chập điện, chuột cắn, sử dụng sai quy cách hay quá thông số kỹ thuật cho phép của sản phẩm.</li>
                <li>Khách hàng tự tháo lắp, sửa chữa sản phẩm.</li>
                <h3>4. NHỮNG BỘ PHẬN SAU KHÔNG THUỘC PHẠM VI BẢO HÀNH:</h3>
                <li>Lớp vải, da bọc, nhựa bọc của sản phẩm. ( trừ khi có phiếu bảo hành riêng cho hạng mục này)</li>
                <li>Lớp vỏ nhựa phần thành ghế, lưng ghế, phần bảo vệ hộp mạch và phần chân ghế.</li>
                <li>Các phụ kiện đi kèm như pin, miếng dán, dây nối (nếu có).</li>
                <h3>5. NHỮNG TRƯỜNG HỢP SỬA CHỮA CÓ TÍNH PHÍ THEO QUY ĐỊNH CỦA CÔNG TY:</h3>
                <li>Sản phẩm không được bảo hành ( trong mục 3) .</li>
                <li>Phụ kiện đi cùng sản phẩm.</li>
                <li>Những bộ phận không thuộc phạm vi bảo hành.</li>
                <p><strong style="font-size: 20px;">* Lưu ý: </strong>Khách hàng không xuất trình được phiếu bảo hành thì toàn bộ các nội dung bảo hành sẽ bị tính phí khi sửa chữa</p>
            </div> `
        }
        document.querySelector("#loadDetail").innerHTML += sp;
    }
}
loadDetail();