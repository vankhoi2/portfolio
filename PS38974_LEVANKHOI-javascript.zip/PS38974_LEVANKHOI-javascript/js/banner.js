var hinh = ['images/banner0.jpg', 'images/banner1.jpg', 'images/banner2.jpg', 'images/banner3.jpg', 'images/banner4.jpg'];
let i = 0;

function right() {
    i++;
    if (i == hinh.length) {
        i = 0
    }
    document.getElementById('banner').src = hinh[i];
}

function left() {
    i--;
    if (i < 0) {
        i = hinh.length - 1;
    }
    document.getElementById('banner').src = hinh[i];
}
setInterval(right, 4000);