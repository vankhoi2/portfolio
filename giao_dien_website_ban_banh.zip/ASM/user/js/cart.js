function changeQuantity(amount) {
    const quantityInput = document.getElementById('quantity');
    let currentValue = parseInt(quantityInput.value);

    // Ensure quantity does not go below 1
    currentValue = Math.max(1, currentValue + amount);

    quantityInput.value = currentValue;
}