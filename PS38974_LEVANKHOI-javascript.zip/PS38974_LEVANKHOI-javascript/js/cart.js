var tt = 0;

function hiengiohang() {
    var sp1 = '';
    cart = JSON.parse(localStorage.getItem("cart"));
    if (cart) cart.forEach((pro, index) => {
        var tc = pro.price * pro.quantity;
        tt += tc;
        sp1 += `
        <tr>
            <td><img src="images/${pro.image}" style="width: 100px;" alt=""></td>
            <td>${pro.name}</td>
            <td>
                <input type="number" min="1" value="${pro.quantity}" 
                    onkeyup='tinhTien(${pro.price},this.value,${index})'
                    onchange='tinhTien(${pro.price},this.value,${index})'
                >
            </td>
            <td>${pro.price} VND</td>
            <td class="tien">${tc} VND</td>
            <td><button onclick="xoaSanPham(${pro.id})">Xóa</button></td>
        </tr>
         `
    });
    document.getElementById("chitietgiohang").innerHTML = sp1;
    tinhtongtien();
}
//cap nhat tien khi sl thay doi
function tinhTien(gia, sl, i) {
    var tien = gia * sl;
    document.getElementsByClassName("tien")[i].innerText = tien + "VND";
    tinhtongtien();
}

function tinhtongtien() {
    var tt = 0;
    document.querySelectorAll(".tien").forEach(function(item) {
        tt += parseFloat(item.innerText);
    });
    document.getElementById('total_tong').innerText = "Tổng tiền : " + tt + " VND";
}

function xoaSanPham(id) {
    var cart = JSON.parse(localStorage.getItem("cart")) || [];
    cart = cart.filter(pro => pro.id !== id);
    localStorage.setItem("cart", JSON.stringify(cart));
    hiengiohang();
    tinhtongtien();
}
hiengiohang();