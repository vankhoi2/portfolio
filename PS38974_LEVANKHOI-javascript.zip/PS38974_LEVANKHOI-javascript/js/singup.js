function checkformdk() {
    var first = document.getElementById("first");
    var last = document.getElementById("last");
    // var gt = document.getElementById("gt");
    var email = document.getElementById("email");
    var password = document.getElementById("password");
    var password2 = document.getElementById("password2");
    //kiem tra first name
    if (first.value != "") {
        if (first.value.length < 2) {
            alert("Vui lòng nhập first name >=2 ki tu");
            first.focus();
            return false;
        }
    } else {
        alert("Vui lòng nhập first name");
        first.focus();
        return false;
    }
    // kiemtra last name
    if (last.value != "") {
        if (last.value.length < 3) {
            alert("Vui lòng nhập last name >=3 ki tu");
            last.focus();
            return false;
        }
    } else {
        alert("Vui lòng nhập last name");
        last.focus();
        return false;
    }

    // kiem tra chon gioi tinh
    var gt = document.getElementsByName("gt");
    if (!gt[0].checked && !gt[1].checked) {
        alert("Vui lòng chon gioi tinh");
        gt[0].focus();
        return false;
    } else {
        // return false;
        email.focus();

    }


    //kiem tra email
    if (email.value != "") {
        if (email.value.length < 5) {
            alert("Vui lòng nhập email >=5 ki tu");
            email.focus();
            return false;
        }
    } else {
        alert("Vui lòng nhập email");
        email.focus();
        return false;
    }
    //kienm tra password
    if (password.value != "") {
        if (password.value.length < 5) {
            alert("Vui lòng nhập password >=5 ki tu");
            password.focus();
            return false;
        }
    } else {
        alert("vui long mật khẩu ");
        password.focus();
        return false;
    }
    //kiem tra lai password
    if (password2.value != "") {
        if (password2.value != password.value) {
            alert("mật khẩu không trùng khớp");
            password2.focus();
            return false;
        }
    } else {
        alert("Vui lòng nhập lại mật khẩu ");
        password2.focus();
        return false;
    }
    var gioit = gt[0].checked ? "Nam" : "Nu";
    confirm("Đăng ký thành công\n" + "Họ và tên: " + last.value + " " + first.value + "\ngioi tinh: " + gioit + " " + "\nEmail: " + email.value + "\nPassword: " + password.value);
    return true;
}