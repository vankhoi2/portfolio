var hinh = ['images/banner1.webp', 'images/banner1.webp', 'images/banner2.webp'];
let i = 0;

function right() {
    i++;
    if (i == hinh.length) {
        i = 0
    }
    document.getElementById('banner').src = hinh[i];
}

function left() {
    i--;
    if (i < 0) {
        i = hinh.length - 1;
    }
    document.getElementById('banner').src = hinh[i];
}
setInterval(right, 3000);