function checkform() {
    var user = document.getElementById("user");
    var pass = document.getElementById("pass");
    var pass2 = document.getElementById("pass2");
    if (user.value != "") {
        if (user.value.length < 6) {
            alert("vui long nhap ten dang nhap >=6 ki tu");
            user.focus();
            return false;
        }
    } else {
        alert("vui long nhap ten dang nhap ");
        user.focus();
        return false;
    }
    if (pass.value != "") {
        if (pass.value.length < 5) {
            alert("vui long nhap pass >=5 ki tu");
            pass.focus();
            return false;
        }
    } else {
        alert("vui long nhap mat khau ");
        pass.focus();
        return false;
    }
    if (pass2.value != "") {
        if (pass2.value != pass.value) {
            alert("mat khau ko trung khop");
            pass2.focus();
            return false;
        }
    } else {
        alert("vui long nhap lai mat khau ");
        pass2.focus();
        return false;
    }
    confirm("Đăng nhập thành công !\nTên đăng nhập: " + user.value + "\nPassword: " + pass.value);
}