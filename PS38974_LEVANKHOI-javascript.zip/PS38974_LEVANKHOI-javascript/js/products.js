var products = [{
        id: 1,
        name: "Ghế massage OKIA eRegal – Royal Massage Experience",
        cate_id: 1,
        image: "anh1.jpg",
        price: 149000000
    }, {
        id: 2,
        name: "Ghế massage OKIA eMonarch LX Human Touch",
        cate_id: 1,
        image: "anh2.jpg",
        price: 281999000
    }, {
        id: 3,
        name: "Ghế massage OKIA eMonarch LX Gold",
        cate_id: 1,
        image: "anh3.jpg",
        price: 339999000
    }, {
        id: 4,
        name: "Ghế Massage nhập khẩu NTK BELLA-TV 2610",
        cate_id: 1,
        image: "anh4.jpg",
        price: 199000000
    }, {
        id: 5,
        name: "Ghế Massger Fujikima STAR LX -FJ-LX778",
        cate_id: 1,
        image: "anh5.jpg",
        price: 199900000
    }, {
        id: 6,
        name: "Ghế Massager Fujikima FJ-909FX",
        cate_id: 1,
        image: "anh6.jpg",
        price: 199000000
    }, {
        id: 7,
        name: "Ghế Massage FUJKIMA STAR- A389",
        cate_id: 1,
        image: "anh7.jpg",
        price: 148900000
    }, {
        id: 8,
        name: "Ghế FUJIKIMA SUNLIGHT FJ-A431",
        cate_id: 1,
        image: "anh8.jpg",
        price: 168000000
    },
    {
        id: 9,
        name: "Ghế FUJIKIMA SUNLIGHT FJ-A431",
        cate_id: 1,
        image: "anh9.jpg",
        price: 168000000
    },
    {
        id: 10,
        name: "Ghế FUJIKIMA SPACE GALAXY 4D-FJ-579",
        cate_id: 1,
        image: "anh10.jpg",
        price: 158000000
    },
    {
        id: 11,
        name: "Ghế FUJIKIMA SPACE GALAXY 4D-FJ-579",
        cate_id: 1,
        image: "anh11.jpg",
        price: 158000000
    },
    {
        id: 12,
        name: "Ghế Massage FUJIKIMA SPACE FJ -296",
        cate_id: 1,
        image: "anh12.jpg",
        price: 118900000
    },
    {
        id: 13,
        name: "Gối Massage HN Magic 8 bi",
        cate_id: 1,
        image: "anh13.jpg",
        price: 360000
    }, {
        id: 14,
        name: "Máy massage giảm mỡ bụng",
        cate_id: 1,
        image: "anh14.jpg",
        price: 3199000
    }, {
        id: 15,
        name: "Massage Vai gáy",
        cate_id: 1,
        image: "anh15.jpg",
        price: 4999000
    }, {
        id: 16,
        name: "Massage chân 4D (Đỏ)",
        cate_id: 1,
        image: "anh16.jpg",
        price: 19999000
    }, {
        id: 17,
        name: "Massage chân 3D (Vàng)",
        cate_id: 1,
        image: "anh17.jpg",
        price: 19999000
    }, {
        id: 18,
        name: "Massage chân 3D (Vàng)",
        cate_id: 1,
        image: "anh18.jpg",
        price: 17999000
    }, {
        id: 19,
        name: "Massage chân 3D (Đỏ)",
        cate_id: 1,
        image: "anh19.jpg",
        price: 17999000
    }, {
        id: 20,
        name: "Gối massage HN FJ-488K",
        cate_id: 1,
        image: "anh20.jpg",
        price: 3199000
    }, {
        id: 21,
        name: "Gối Massage Hồng Ngoại",
        cate_id: 1,
        image: "anh21.jpg",
        price: 360000
    }, {
        id: 22,
        name: "Food massage 4D (Cafe)",
        cate_id: 1,
        image: "anh22.jpg",
        price: 19900000
    }, {
        id: 23,
        name: "Đệm Massage 3D (Nâu)",
        cate_id: 1,
        image: "anh23.jpg",
        price: 14999000
    }, {
        id: 24,
        name: "Đệm Massage 3D",
        cate_id: 1,
        image: "anh24.jpg",
        price: 14999000
    },
];