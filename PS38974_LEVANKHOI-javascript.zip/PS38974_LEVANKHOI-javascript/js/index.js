function arr_Detail(id) {
    sessionStorage.setItem('id_Detail', id);
    location.href = "detail.html";
}

function themvaogio(id, ten, hinh, gia) {
    var cart = JSON.parse(localStorage.getItem("cart"));
    if (cart == null) {
        cart = [];
        cart.push({ id: id, name: ten, image: hinh, price: gia, quantity: 1 });
    } else {
        let item = cart.find(item => item.id === id);
        if (item) quantity = item.quantity + 1;
        else cart.push({ id: id, name: ten, image: hinh, price: gia, quantity: 1 });
    }
    localStorage.setItem("cart", JSON.stringify(cart));
    // location.href = "giohang.html";
    alert("Đã thêm vào giỏ hàng !")
}

products.forEach(el => {
    let sp1 = `<div class="box-4 mg20 ">
    <a onclick = "arr_Detail(${el.id})" href="#"><img src="images/${el.image} " alt=" "></a>
    <div class="icons-left">
        <img src="https://www.hihoy.com/files/img/newpng.png" alt=""></a>
    </div>
    <div class="name ">
        <a onclick = "arr_Detail(${el.id})" href="#">${el.name}</a>
    </div>
    <div class="gia ">
        <a onclick = "arr_Detail(${el.id})" href="#">${el.price}đ</a>
    </div>
    <div class="star">
        <a href="#"><i class="fa-solid fa-star"></i></a>
        <a href="#"><i class="fa-solid fa-star"></i></a>
        <a href="#"><i class="fa-solid fa-star"></i></a>
        <a href="#"><i class="fa-solid fa-star"></i></a>
        <a href="#"><i class="fa-regular fa-star"></i></a>
    </div>
    <div class="add">
    <a onclick="showcar()"></a>
    <i class="fa-solid fa-cart-shopping"></i>
    <button id="thanhcong" onclick = "themvaogio(${el.id}, '${el.name}', '${el.image}', ${el.price})"> Thêm giỏ hàng</button>
    </div>
    `;
    document.getElementById("loadsp").innerHTML += sp1;
});

const btn = document.querySelector("#thanhcong");
const btn1 = document.querySelector("#popcart");
btn.addEventListener("click", () => {
    btn1.classList.add("active");
    setTimeout(() => {
        btn1.classList.remove("active");
    }, 2000);
});